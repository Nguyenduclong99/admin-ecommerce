DROP TABLE IF EXISTS post_tag CASCADE;
DROP TABLE IF EXISTS tags CASCADE;
DROP TABLE IF EXISTS user_role CASCADE;
DROP TABLE IF EXISTS roles CASCADE;
DROP TABLE IF EXISTS comments CASCADE;
DROP TABLE IF EXISTS posts CASCADE;
DROP TABLE IF EXISTS photos CASCADE;
DROP TABLE IF EXISTS albums CASCADE;
DROP TABLE IF EXISTS todos CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS address CASCADE;
DROP TABLE IF EXISTS company CASCADE;
DROP TABLE IF EXISTS geo CASCADE;

CREATE TABLE tags (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT NOT NULL,
  updated_by BIGINT NOT NULL
);

CREATE TABLE geo (
  id BIGSERIAL PRIMARY KEY,
  lat VARCHAR(255),
  lng VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT
);

CREATE TABLE company (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255),
  catch_phrase VARCHAR(255),
  bs VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT
);

CREATE TABLE address (
  id BIGSERIAL PRIMARY KEY,
  street VARCHAR(255),
  suite VARCHAR(255),
  city VARCHAR(255),
  zipcode VARCHAR(255),
  geo_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT,
  CONSTRAINT fk_geo FOREIGN KEY (geo_id) REFERENCES geo (id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE INDEX idx_address_geo_id ON address (geo_id);

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  first_name VARCHAR(255) NOT NULL,
  last_name VARCHAR(255) NOT NULL,
  username VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  address_id BIGINT,
  phone VARCHAR(255),
  website VARCHAR(255),
  company_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_address FOREIGN KEY (address_id) REFERENCES address (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_company FOREIGN KEY (company_id) REFERENCES company (id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE INDEX idx_users_address_id ON users (address_id);
CREATE INDEX idx_users_company_id ON users (company_id);

CREATE TABLE todos (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  completed BOOLEAN DEFAULT false,
  user_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT,
  CONSTRAINT fk_user_todos FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE INDEX idx_todos_user_id ON todos (user_id);

CREATE TABLE albums (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  user_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT,
  CONSTRAINT fk_user_album FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE INDEX idx_albums_user_id ON albums (user_id);

CREATE TABLE photos (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  url VARCHAR(255) NOT NULL,
  thumbnail_url VARCHAR(255) NOT NULL,
  album_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT,
  CONSTRAINT fk_album FOREIGN KEY (album_id) REFERENCES albums (id)
);

CREATE INDEX idx_photos_album_id ON photos (album_id);

CREATE TABLE posts (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  user_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  updated_by BIGINT,
  CONSTRAINT fk_user_post FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE INDEX idx_posts_user_id ON posts (user_id);

CREATE TABLE post_tag (
  id BIGSERIAL PRIMARY KEY,
  post_id BIGINT NOT NULL,
  tag_id BIGINT NOT NULL,
  CONSTRAINT fk_posttag_post_id FOREIGN KEY (post_id) REFERENCES posts (id),
  CONSTRAINT fk_posttag_tag_id FOREIGN KEY (tag_id) REFERENCES tags (id)
);

CREATE INDEX idx_post_tag_post_id ON post_tag (post_id);
CREATE INDEX idx_post_tag_tag_id ON post_tag (tag_id);

CREATE TABLE comments (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  post_id BIGINT,
  user_id BIGINT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT NOT NULL,
  updated_by BIGINT NOT NULL,
  CONSTRAINT fk_comment_post FOREIGN KEY (post_id) REFERENCES posts (id),
  CONSTRAINT fk_comment_user FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE INDEX idx_comments_post_id ON comments (post_id);
CREATE INDEX idx_comments_user_id ON comments (user_id);

CREATE TABLE roles (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL
);

CREATE TABLE user_role (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  role_id BIGINT NOT NULL,
  CONSTRAINT fk_security_user_id FOREIGN KEY (user_id) REFERENCES users (id),
  CONSTRAINT fk_security_role_id FOREIGN KEY (role_id) REFERENCES roles (id)
);

CREATE INDEX idx_user_role_user_id ON user_role (user_id);
CREATE INDEX idx_user_role_role_id ON user_role (role_id);

-- Replace LOCK TABLES with direct INSERT in PostgreSQL
INSERT INTO roles (id, name) VALUES 
(1, 'ROLE_ADMIN'),
(2, 'ROLE_USER');

-- Reset sequences to start after the inserted values
SELECT setval('roles_id_seq', (SELECT MAX(id) FROM roles));